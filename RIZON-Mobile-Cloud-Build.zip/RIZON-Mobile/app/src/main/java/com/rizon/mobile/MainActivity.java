package com.rizon.mobile;

import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.media.MediaPlayer;

import androidx.annotation.Nullable;
import android.app.Activity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private VideoView wallpaper;
    private TextView timeText, dateText, greetingText, nameText, weatherTemp, weatherInfo;
    private EditText searchBox;
    private final Handler handler = new Handler();
    private SharedPreferences prefs;
    private boolean zenMode = false;

    private final Runnable clockRunnable = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("rizon", MODE_PRIVATE);
        bindViews();
        setupWallpaper();
        setupSearch();
        setupButtons();
        updateClock();
        handler.post(clockRunnable);

        String city = prefs.getString("city", "Islamabad");
        loadWeather(city);
    }

    private void bindViews() {
        wallpaper = findViewById(R.id.wallpaper);
        timeText = findViewById(R.id.timeText);
        dateText = findViewById(R.id.dateText);
        greetingText = findViewById(R.id.greetingText);
        nameText = findViewById(R.id.nameText);
        weatherTemp = findViewById(R.id.weatherTemp);
        weatherInfo = findViewById(R.id.weatherInfo);
        searchBox = findViewById(R.id.searchBox);
    }

    private void setupWallpaper() {
        Uri video = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.rizon_default);
        wallpaper.setVideoURI(video);
        wallpaper.setOnPreparedListener(mp -> {
            mp.setLooping(true);
            mp.setVolume(0f, 0f);
            String mode = prefs.getString("performance", "Balanced");
            if ("Low".equals(mode) || "Battery Saver".equals(mode)) {
                mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(0.9f));
            }
            wallpaper.start();
        });
        wallpaper.setOnErrorListener((mp, what, extra) -> {
            wallpaper.setBackgroundColor(Color.rgb(5,5,7));
            Toast.makeText(this, "RIZON wallpaper video could not play; using dark fallback.", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void setupSearch() {
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                performSearch(searchBox.getText().toString().trim());
                return true;
            }
            return false;
        });
    }

    private void performSearch(String query) {
        if (query.isEmpty()) return;
        String url;
        if (query.startsWith("http://") || query.startsWith("https://")) {
            url = query;
        } else {
            url = "https://www.google.com/search?q=" + Uri.encode(query);
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "No browser found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupButtons() {
        findViewById(R.id.appDrawerButton).setOnClickListener(v -> showAppDrawer());
        findViewById(R.id.settingsButton).setOnClickListener(v -> showSettings());
    }

    private void updateClock() {
        Date now = new Date();
        SimpleDateFormat time = new SimpleDateFormat(
                prefs.getBoolean("24h", false) ? "HH:mm" : "hh:mm a", Locale.getDefault());
        SimpleDateFormat date = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault());

        timeText.setText(time.format(now));
        dateText.setText(date.format(now));

        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        String greeting;
        if (h < 12) greeting = "GOOD MORNING";
        else if (h < 17) greeting = "GOOD AFTERNOON";
        else if (h < 21) greeting = "GOOD EVENING";
        else greeting = "GOOD NIGHT";
        greetingText.setText(greeting);

        String name = prefs.getString("name", "");
        nameText.setText(name.isEmpty() ? "Welcome back" : "Welcome back, " + name);
    }

    private void showAppDrawer() {
        final List<ApplicationInfo> apps = getLaunchableApps();
        final ArrayList<String> names = new ArrayList<>();
        for (ApplicationInfo app : apps) {
            names.add(app.loadLabel(getPackageManager()).toString());
        }

        final EditText filter = new EditText(this);
        filter.setHint("Search apps");
        filter.setSingleLine(true);
        filter.setTextColor(Color.WHITE);
        filter.setHintTextColor(0x99FFFFFF);
        filter.setBackgroundColor(0xFF17171B);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(18, 10, 18, 10);
        layout.setBackgroundColor(0xFF09090C);
        layout.addView(filter, new LinearLayout.LayoutParams(-1, 52));

        GridView grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setVerticalSpacing(10);
        grid.setHorizontalSpacing(8);
        grid.setPadding(0, 14, 0, 0);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, names) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);
                tv.setTextColor(Color.WHITE);
                tv.setGravity(Gravity.CENTER);
                tv.setPadding(4, 18, 4, 18);
                tv.setBackgroundColor(0x66141418);
                return tv;
            }
        };
        grid.setAdapter(adapter);
        layout.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("RIZON APP DRAWER")
                .setView(layout)
                .setNegativeButton("CLOSE", null)
                .create();
        dialog.getWindow();
        dialog.setOnShowListener(d -> {
            filter.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
                    String q = s.toString().toLowerCase(Locale.getDefault());
                    ArrayList<String> filtered = new ArrayList<>();
                    for (String n : names) if (n.toLowerCase(Locale.getDefault()).contains(q)) filtered.add(n);
                    adapter.clear(); adapter.addAll(filtered); adapter.notifyDataSetChanged();
                }
                @Override public void afterTextChanged(android.text.Editable e) {}
            });
        });

        grid.setOnItemClickListener((parent, view, position, id) -> {
            String selectedName = (String) adapter.getItem(position);
            for (ApplicationInfo app : apps) {
                String n = app.loadLabel(getPackageManager()).toString();
                if (n.equals(selectedName)) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
                    if (launch != null) {
                        startActivity(launch);
                        dialog.dismiss();
                    }
                    break;
                }
            }
        });

        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) w.setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.94),
                (int)(getResources().getDisplayMetrics().heightPixels * 0.78));
    }

    private List<ApplicationInfo> getLaunchableApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ApplicationInfo> result = new ArrayList<>();
        for (android.content.pm.ResolveInfo ri : getPackageManager().queryIntentActivities(intent, 0)) {
            if (ri.activityInfo != null && !ri.activityInfo.packageName.equals(getPackageName())) {
                try {
                    result.add(getPackageManager().getApplicationInfo(ri.activityInfo.packageName, 0));
                } catch (Exception ignored) {}
            }
        }
        Collections.sort(result, Comparator.comparing(a ->
                a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.getDefault())));
        return result;
    }

    private void showSettings() {
        String[] options = {
                "Set RIZON as Default Home App",
                "Change Name",
                "Change Weather City",
                "12/24 Hour Clock",
                "Performance Mode",
                "Zen Mode",
                "Open Android Home Settings"
        };

        new AlertDialog.Builder(this)
                .setTitle("RIZON SETTINGS")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: setAsDefaultLauncher(); break;
                        case 1: changeName(); break;
                        case 2: changeCity(); break;
                        case 3:
                            prefs.edit().putBoolean("24h", !prefs.getBoolean("24h", false)).apply();
                            updateClock();
                            Toast.makeText(this, "Clock format updated.", Toast.LENGTH_SHORT).show();
                            break;
                        case 4: choosePerformance(); break;
                        case 5: toggleZenMode(); break;
                        case 6:
                            try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
                            catch (Exception e) { Toast.makeText(this, "Home settings unavailable.", Toast.LENGTH_SHORT).show(); }
                            break;
                    }
                }).show();
    }

    private void setAsDefaultLauncher() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
            Toast.makeText(this, "Select RIZON Mobile as your Home app.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Open Android Settings > Apps > Default apps > Home app.", Toast.LENGTH_LONG).show();
        }
    }

    private void changeName() {
        final EditText input = new EditText(this);
        input.setHint("Your name");
        input.setSingleLine(true);
        input.setText(prefs.getString("name", ""));
        new AlertDialog.Builder(this).setTitle("RIZON NAME").setView(input)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    prefs.edit().putString("name", input.getText().toString().trim()).apply();
                    updateClock();
                }).show();
    }

    private void changeCity() {
        final EditText input = new EditText(this);
        input.setHint("City, e.g. Islamabad");
        input.setSingleLine(true);
        input.setText(prefs.getString("city", "Islamabad"));
        new AlertDialog.Builder(this).setTitle("WEATHER CITY").setView(input)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    String city = input.getText().toString().trim();
                    if (city.isEmpty()) return;
                    prefs.edit().putString("city", city).apply();
                    loadWeather(city);
                }).show();
    }

    private void choosePerformance() {
        String[] modes = {"Ultra", "High", "Balanced", "Low", "Battery Saver", "Static"};
        String current = prefs.getString("performance", "Balanced");
        int checked = 2;
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(current)) checked = i;
        new AlertDialog.Builder(this)
                .setTitle("PERFORMANCE MODE")
                .setSingleChoiceItems(modes, checked, (d, which) -> {
                    prefs.edit().putString("performance", modes[which]).apply();
                    d.dismiss();
                    if ("Static".equals(modes[which])) {
                        wallpaper.pause();
                    } else if (!wallpaper.isPlaying()) {
                        wallpaper.start();
                    }
                    Toast.makeText(this, modes[which] + " enabled.", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void toggleZenMode() {
        zenMode = !zenMode;
        findViewById(R.id.weatherCard).setVisibility(zenMode ? View.GONE : View.VISIBLE);
        findViewById(R.id.searchBox).setVisibility(zenMode ? View.GONE : View.VISIBLE);
        findViewById(R.id.appDrawerButton).setVisibility(zenMode ? View.GONE : View.VISIBLE);
        findViewById(R.id.bottomBar).setVisibility(zenMode ? View.GONE : View.VISIBLE);
        Toast.makeText(this, zenMode ? "ZEN MODE ON" : "ZEN MODE OFF", Toast.LENGTH_SHORT).show();
    }

    private void loadWeather(final String city) {
        weatherTemp.setText("--°C");
        weatherInfo.setText(city + " • loading…");

        new Thread(() -> {
            try {
                String geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                        Uri.encode(city) + "&count=1&language=en&format=json";
                String geo = httpGet(geoUrl);
                double lat = extractDouble(geo, "\"latitude\":", 0);
                double lon = extractDouble(geo, "\"longitude\":", 0);
                if (lat == 0 && lon == 0) throw new Exception("City not found");

                String weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=" +
                        lat + "&longitude=" + lon + "&current=temperature_2m,weather_code&timezone=auto";
                String data = httpGet(weatherUrl);
                double temp = extractDouble(data, "\"temperature_2m\":", 0);
                int code = (int) extractDouble(data, "\"weather_code\":", -1);
                final String condition = weatherName(code);

                runOnUiThread(() -> {
                    weatherTemp.setText(Math.round(temp) + "°C");
                    weatherInfo.setText(city + " • " + condition);
                });
            } catch (Exception e) {
                runOnUiThread(() -> weatherInfo.setText(city + " • unavailable"));
            }
        }).start();
    }

    private String httpGet(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(6000);
        c.setRequestMethod("GET");
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        c.disconnect();
        return sb.toString();
    }

    private double extractDouble(String text, String key, double fallback) {
        Pattern p = Pattern.compile(Pattern.quote(key) + "\\s*(-?\\d+(?:\\.\\d+)?)");
        Matcher m = p.matcher(text);
        return m.find() ? Double.parseDouble(m.group(1)) : fallback;
    }

    private String weatherName(int code) {
        if (code == 0) return "Clear";
        if (code <= 3) return "Cloudy";
        if (code <= 48) return "Fog";
        if (code <= 57) return "Drizzle";
        if (code <= 67) return "Rain";
        if (code <= 77) return "Snow";
        if (code <= 82) return "Showers";
        if (code <= 86) return "Snow showers";
        if (code <= 99) return "Storm";
        return "Unknown";
    }

    @Override protected void onPause() {
        super.onPause();
        if (!"Ultra".equals(prefs.getString("performance", "Balanced"))) {
            wallpaper.pause();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (!"Static".equals(prefs.getString("performance", "Balanced"))) {
            wallpaper.start();
        }
        updateClock();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockRunnable);
        super.onDestroy();
    }
}
