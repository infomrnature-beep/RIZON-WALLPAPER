RIZON uses a vector red-eye icon. Android Studio can generate adaptive launcher icons later if desired.
