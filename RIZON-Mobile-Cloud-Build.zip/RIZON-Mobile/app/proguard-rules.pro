# RIZON Mobile currently uses no custom ProGuard rules.
