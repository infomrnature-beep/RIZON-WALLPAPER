# Build RIZON Mobile APK for free (phone-friendly route)

This source project is not itself an installable APK. GitHub Actions can compile it in the cloud.

1. Sign in to GitHub and create a **new empty repository** named `RIZON-Mobile`. A free account is enough. Do not add a README, license, or `.gitignore` when creating it.
2. On GitHub, open the new repository and choose **Add file → Upload files**.
3. Extract `RIZON-Mobile-Android-Project.zip` first. Upload the **contents inside the `RIZON-Mobile` folder**, including the hidden `.github` folder. If the phone file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow from this project's same path.
4. Commit the uploaded files to the `main` branch.
5. Open the repository's **Actions** tab and choose **Build RIZON Mobile APK**. If it doesn't start automatically, press **Run workflow**.
6. Wait for the workflow to finish with a green check. Open that run and download the artifact named **RIZON-Mobile-debug-APK**.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install. Android may ask you to allow installs from your browser/file manager; only enable this for the app you're using to install, then turn it off afterward.
8. Open RIZON Mobile and set it as the default Home app when prompted.

The build is unsigned with a release key (a normal debug APK), intended for testing on your own phone. Keep your source repository private if you prefer not to publish the project publicly.
