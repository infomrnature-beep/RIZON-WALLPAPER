# RIZON Mobile

RIZON Mobile is a lightweight Android Home/Launcher project designed for older Android phones, with the Infinix HOT 9 / Android 10 as the first target.

## Included MVP
- RIZON anime video wallpaper (the supplied red-eye video is bundled as the default wallpaper)
- Live clock and date
- Smart time-based greeting
- Weather by city using Open-Meteo (no API key)
- Search bar
- App drawer with app search
- Settings
- Name customization
- Weather city customization
- 12/24 hour clock
- Performance modes
- Zen mode
- Default Home/Launcher setup
- Local settings via SharedPreferences
- No account and no mandatory API key

## Important
This project does NOT replace the secure Android system lock screen. It is a Home/Launcher app. Users keep Android's normal PIN/pattern/password/biometric lock screen.

## Build
Open this folder in Android Studio with internet access so Gradle can download the Android Gradle Plugin and Android SDK components.

Then:
1. Sync Gradle.
2. Build > Make Project.
3. Build > Build APK(s).
4. Install the generated APK on the Android 10 phone.
5. Open RIZON Mobile.
6. Choose Settings > Set RIZON as Default Home App.
7. Select RIZON Mobile.

## Notes
- The weather service is Open-Meteo and does not require an API key.
- Weather city is manually selectable in this MVP.
- The bundled video is used as the default wallpaper.
- If the device cannot decode the bundled video codec, RIZON falls back to a dark background.
- The launcher is intentionally dependency-light for older hardware.

## Next versions
Potential v1.1/v2 work: editable shortcut dock, icon packs, static wallpaper picker, wallpaper import UI, more widgets, animated weather overlays, backup/restore, app categories, notification badge support, and deeper battery/performance tuning.

## Build an APK without installing Android Studio
See [BUILD-APK-FREE.md](BUILD-APK-FREE.md). The included GitHub Actions workflow builds a debug APK in the cloud and publishes it as a downloadable workflow artifact.
