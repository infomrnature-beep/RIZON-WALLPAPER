@echo off
echo RIZON Mobile build helper
echo.
echo Open this project in Android Studio and let it sync Gradle.
echo Then choose Build ^> Build APK(s).
pause
